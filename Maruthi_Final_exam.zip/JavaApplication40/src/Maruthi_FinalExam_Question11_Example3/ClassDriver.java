//ClassDriver.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question11_Example3;

/**
 *
 * @author S541905
 */
public class ClassDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("The answer for Question11 as follows by Priyanka Maruthi");
        System.out.println("Example2");
        ClassRoom T1=new ClassRoom(40,"colden hall");
        ClassRoom T2=new ClassRoom(40,"colden hall");
        ClassRoom T3=new ClassRoom(43,"valk building");
        System.out.println("*********************************");
        //TOSTRING method of Train class will be invoked
        System.out.println("**************To string method**************");
        System.out.println(T1);
        System.out.println(T2);
        System.out.println(T3);
     
     System.out.println("**************.equals **************");
        System.out.println(T1.equals(T2));
        System.out.println(T1.equals(T3));
        System.out.println(T2.equals(T3));

        System.out.println("************** == **************");
        System.out.println((T1 == T2));
        System.out.println((T1 == T3));
        System.out.println((T2 == T3));

        System.out.println("**************hashcode **************");
        System.out.println(T1.hashCode());
        System.out.println(T2.hashCode());
        System.out.println(T3.hashCode());
        
        System.out.println("**************address**************");
        System.out.println(Integer.toHexString(System.identityHashCode(T1)));
        System.out.println(Integer.toHexString(System.identityHashCode(T2)));
        System.out.println(Integer.toHexString(System.identityHashCode(T3)));
    }

}

//Climate.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question9_Example2;

/**
 *
 * @author S541905
 */
public class Climate {
    
 private String winddirection;
    private double temperature;
    private boolean snowing;

    public Climate(String winddirection, double temperature, boolean snowing) {
        this.winddirection = winddirection;
        this.temperature = temperature;
        this.snowing = snowing;
    }

    public String getWinddirection() {
        return winddirection;
    }

    public void setWinddirection(String winddirection) {
        this.winddirection = winddirection;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public boolean isSnowing() {
        return snowing;
    }

    public void setSnowing(boolean snowing) {
        this.snowing = snowing;
    }
    public boolean checkTemperature() throws NegativeTemperatureException 
  {
   if(temperature<0.0){
       System.out.println("Throwing user defined exception:NegativeTemperatureException");
      throw new NegativeTemperatureException("Please take care temperature below 0.0 degree celsius");   
   }
       else 
       return true;
  }
    @Override
    public String toString() {
        return "Weather{" + "winddirection=" + winddirection + ", temperature=" + temperature + ", snowing=" + snowing + '}';
    }
    
    
}

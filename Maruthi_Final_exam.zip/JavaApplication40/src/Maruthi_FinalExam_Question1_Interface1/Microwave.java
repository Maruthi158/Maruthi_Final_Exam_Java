//Microwave.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1_Interface1;

/**
 *
 * @author Priyanka Maruthi
 */
public class Microwave implements ElectronicsInterface {
    private int modelNo;
    private String color;
    private int price;

    public Microwave(int modelNo, String color, int price) {
        this.modelNo = modelNo;
        this.color = color;
        this.price = price;
    }

    public int getModelNo() {
        return modelNo;
    }

    public void setModelNo(int modelNo) {
        this.modelNo = modelNo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Microwave{" + "modelNo=" + modelNo + ", color=" + color + ", price=" + price + '}';
    }

    @Override
    public String typeOfElectronics() {
       return "The type of Electronic item is : Microwave";
    }
    
    
}

//MusicalInstruments.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1_Interface2;

/**
 *
 * @author Priyanka Maruthi
 */
public interface MusicalInstruments {
      public static final String isMusicPlayable="YES";
    public abstract String typeofMusicalInstrument();
      default String isInstrumentRequiresBattery(){
         return "The battery required for the musical instrument";
     }
    
    
}

//CompartmentDriver.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question8_Example1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author S541905
 */
public class CompartmentDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        System.out.println("The answer for Question8  as follows by Priyanka Maruthi");
        System.out.println("Example1 showing both user defined exception:WrongTrainNumber and predefined exception:FileNotFoundException");
        // TODO code application logic here
        System.out.println("***********************************");
    Compartment c1=new Compartment(0000,"priya",000);
        System.out.println(c1);

  try{  System.out.println("entering try block");
         System.out.println(c1.checkCompartment());
         }
   
         catch(WrongTrainNumber ex){//specific exception
             System.out.println("Entering catch block exception handling");
           System.out.println(ex+" "+ex.getMessage()); 
         }
   System.out.println("***********************************");
   Scanner scan = new Scanner(new File("CompartmentDetails.txt"));
        
        
        while (scan.hasNext())
        {
           
            Compartment c2 = new Compartment(scan.nextInt(),scan.next(),scan.nextInt());
            System.out.println(c2);
            try{
                System.out.println("entering try block");
                  System.out.println(c2.checkCompartment());
         }
   
         catch(WrongTrainNumber ex){//specific exception
              System.out.println("Entering catch block exception handling");
           System.out.println(ex+" "+ex.getMessage()); 
         }
            System.out.println("***********************************");
     
           
            
        }
    
        scan.close();
  
        
     
    }
   
}

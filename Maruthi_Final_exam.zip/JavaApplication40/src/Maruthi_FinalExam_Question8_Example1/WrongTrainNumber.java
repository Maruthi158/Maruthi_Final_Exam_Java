//WrongTrainNumber.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question8_Example1;

/**
 *
 * @author S541905
 */
public class WrongTrainNumber extends RuntimeException{

    /**
     * Creates a new instance of <code>WrongTrainNumber</code> without detail
     * message.
     */
    public WrongTrainNumber() {
    }

    /**
     * Constructs an instance of <code>WrongTrainNumber</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public WrongTrainNumber(String msg) {
        super(msg);
    }
}

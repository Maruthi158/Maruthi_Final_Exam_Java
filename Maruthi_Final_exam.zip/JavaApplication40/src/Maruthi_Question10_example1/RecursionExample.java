//RecursionExample.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_Question10_example1;

/**
 *
 * @author S541905
 */
public class RecursionExample {
    
 static int arr1[] = {144, 134, 154, 12, 13};
      
     /* Recursive Method to search x in arr[l..r] */
     static int recSearch(int arr[], int left, int right, int x)
     {
          if (right < left)
             return -1;
          if (arr[left] == x)
             return left;
          if (arr[right] == x)
             return right;
          return recSearch(arr, left+1, right-1, x);
     }
}
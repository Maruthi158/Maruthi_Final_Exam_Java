/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question3;

/**
 *
 * @author Priyanka Maruthi
 */
public class CastingDemo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("The answer for Question3 as follows by Priyanka Maruthi");
        System.out.println("Casting Example 1");
        System.out.println("Primitive Data types conversion");
        System.out.println("***************************************");
        System.out.println("Implicit type casting");
        int num=80;
        System.out.println("The integer value : "+num);
        double num1=num;
        System.out.println("The double value for num1 : "+num1);
        System.out.println("***************************************");
        System.out.println("Explicit type casting");
        double num2 = 5.84;
    System.out.println("The double value of num2: " + num2);
       int num3 = (int)num2;
    System.out.println("The integer value for num2: " + num3);
    System.out.println("***************************************");
        System.out.println("Conversion of integer to String");
     int num4= 10;
    System.out.println("The integer value is of num4: " + num4);

    String data1 = String.valueOf(num4);
    System.out.println("The string value of num4 is : " + data1);
    System.out.println("***************************************");
        System.out.println("Conversion of String to integer");  
        String data2 = "10";
    System.out.println("The string value of data2 is : " + data2);
        int num5 = Integer.parseInt(data2);
    System.out.println("The integer value of data2 is : " + num5);
        
    }
    
}

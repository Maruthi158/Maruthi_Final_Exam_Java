//ElectronicsDriver
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1;

/**
 *
 * @author Priyanka Maruthi
 */
public class ElectronicsDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("The answer for Question 1 as follows by Priyanka Maruthi ");
        System.out.println("Abstract Class Example1:");
         System.out.println("*************************************");
        AirConditioner A1=new AirConditioner(1,"Red","window");
        System.out.println(A1);
        System.out.println("Invoking abstract methodS on AirConditioner class");
        System.out.println("typeOfElectronicItem : "+A1.typeOfElectronicItem());
        System.out.println("priceOfElectronicItem "+A1.priceOfElectronicItem());
        System.out.println("*************************************");
        WashingMachine W1=new WashingMachine(2,"Green","front load");
        System.out.println(W1);
        System.out.println("Invoking abstract methods on WashingMachine class");
         System.out.println("typeOfElectronicItem : "+W1.typeOfElectronicItem());
        System.out.println("priceOfElectronicItem "+W1.priceOfElectronicItem());
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_Question10_Example2;

/**
 *
 * @author S541905
 */
public class InfiniteRecursion {

    
    
   public  static void BinarySearch(int[] A,int beg,int last,int item) {
        int mid=(last+beg)/2;
        if ((beg)<=last){
            System.out.println("entering if clause to check starting position is less than last");
             if (item==A[mid])
                 System.out.println("First Item found at position :"+ mid);
        
        else{
                  if (item<A[mid]){
                      System.out.println("second Searching before middle element");
                  BinarySearch(A,beg,mid,item);}
                  else{
                       System.out.println("Third Searching after middle element");
                       BinarySearch(A,mid,last,item);
                        
                         }
                       }
                            
                       
                         
                   
                  }
             
             
             
        else
        {
            System.out.println("Item not found");
        }
        
        
        
    }

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("The answer for Question 10 as follows by Priyanka Maruthi");
        System.out.println("Infinite recursion using search example");
        System.out.println("****************************");
        int[] a={1,2,3,4,5};
       
        int beg=0;
        int last=a.length;
        int item=6;
        System.out.println("Calling Recursive binary search function");
        BinarySearch(a,beg,last,item);
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question8_Example2;

/**
 *
 * @author S541905
 */
public class ExceptionExample2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ArrayIndexOutOfBoundsException,Exception {
        // TODO code application logic here
        System.out.println("The anwer for Question8 as follows by Priyanka Maruthi");
        System.out.println("Question 8 Example2");
        System.out.println("*****************************");
        
     {
      try{
          System.out.println("Inside try block");
         int arr[]=new int[5];
         arr[6]=10;
         
         
      }
      
      catch(ArrayIndexOutOfBoundsException e){
           System.out.println("*****************************");
          System.out.println("Inside catch of ArrayIndexOutOfBoundsException ");
         System.out.println("Accessing array elements outside of the limit");
      }
      catch(Exception e){
           System.out.println("*****************************");
           System.out.println("Inside catch of Exception ");
         System.out.println("Some Other Exception");
      }
       System.out.println("*****************************");
      System.out.println("Out of the try-catch block");
   }
    }}

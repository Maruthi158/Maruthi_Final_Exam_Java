//GeometricObject.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FnalExam_Question2;

/**
 *
 * @author S541905
 */
public abstract class GeometricObject {
   private String color ;
	private boolean fill;


	/** Construct a default geometric object */
	public GeometricObject() {
		
	}

	/** Construct a geometric object with color and filled value */
	public GeometricObject(String color, boolean fill) {
		
		this.color = color;
		this.fill = fill;
	}

	/** Return color */
	public String getColor() {
		return color;
	}

	/** Set a new color */
	public void setColor(String color) {
		this.color = color;
	}

	/** Return filled. Since filled is boolean,
	 *  the get method is named isFilled */
	public boolean isFill() {
		return fill;
	}

	/** Set a new filled */
	public void setFill(boolean fill) {
		this.fill = fill;
	}



	@Override
	public String toString() {
		return 
                        "\ncolor: " + color +
			" and filled: " + fill;
	}

	/** Abstract method getArea */
	public abstract double getArea();


}

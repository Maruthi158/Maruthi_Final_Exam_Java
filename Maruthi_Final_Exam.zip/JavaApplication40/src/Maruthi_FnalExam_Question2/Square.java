//Square.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FnalExam_Question2;

/**
 *
 * @author S541905
 */
public class Square extends GeometricObject implements Colorable {
	private double side;

	

	public Square(double side) {
		this.side = side;
	}

	public Square(double side, String color, boolean fill) {
		super(color, fill);
		setSide(side);
	}

	public void setSide(double side) {
		this.side = side;
	}

	public double getSide() {
		return side;
	}

	@Override
	public double getArea() {
		return Math.pow(side, 2);
	}

	
	
	

	@Override
	public String toString() {
		return super.toString() + "\nSide: " + side + "\nArea: " + getArea();
	}

    @Override
    public void howToColor() {
        System.out.println("Color all four sides");
    }
}

//Vechile.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1_abstractExample2;

/**
 *
 * @author Priyanka Maruthi
 */
public abstract class Vechile {
    
    public abstract String typeofVechile();
    public abstract String CostofVechile();
    
    
}

//VechileDriver.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1_abstractExample2;

/**
 *
 * @author Priyanka Maruthi
 */
public class VechileDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      System.out.println("The answer for Question 1 as follows by Priyanka Maruthi ");
        System.out.println("Abstract Class Example2:");
         System.out.println("*************************************");
        Car A1=new Car(1234,"Mazda");
        System.out.println(A1);
        System.out.println("Invoking abstract methodS on Car class");
        System.out.println(A1.typeofVechile());
        System.out.println(A1.CostofVechile());
        System.out.println("*************************************");
        Bicycle W1=new Bicycle(256,"Hercules");
        System.out.println(W1);
        System.out.println("Invoking abstract methods on Bicycle class");
         System.out.println(W1.typeofVechile());
        System.out.println(W1.CostofVechile());
    }
    
}

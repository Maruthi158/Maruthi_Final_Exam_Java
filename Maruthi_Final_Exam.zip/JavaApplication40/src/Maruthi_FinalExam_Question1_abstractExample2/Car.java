//Car.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1_abstractExample2;

/**
 *
 * @author Priyanka Maruthi
 */
public class Car extends Vechile {
    private int carNo;
    private String carName;

    public Car(int carNo, String carName) {
        this.carNo = carNo;
        this.carName = carName;
    }

    public int getCarNo() {
        return carNo;
    }

    public void setCarNo(int carNo) {
        this.carNo = carNo;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    @Override
    public String toString() {
        return "Car{" + "carNo=" + carNo + ", carName=" + carName + '}';
    }

    @Override
    public String typeofVechile() {
        return "The vechile would be a CAR";
    }

    @Override
    public String CostofVechile() {
        return "The cost of Vechile is $2000.0";
    }
    
    
}

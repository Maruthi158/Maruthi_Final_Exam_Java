//Bicycle.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1_abstractExample2;

/**
 *
 * @author Priyanka Maruthi
 */
public class Bicycle extends Vechile {
     private int bicycleId;
    private String bicycleName;

    public Bicycle(int bicycleId, String bicycleName) {
        this.bicycleId = bicycleId;
        this.bicycleName = bicycleName;
    }

    public int getBicycleId() {
        return bicycleId;
    }

    public void setBicycleId(int bicycleId) {
        this.bicycleId = bicycleId;
    }

    public String getBicycleName() {
        return bicycleName;
    }

    public void setBicycleName(String bicycleName) {
        this.bicycleName = bicycleName;
    }

    @Override
    public String toString() {
        return "Bicycle{" + "bicycleId=" + bicycleId + ", bicycleName=" + bicycleName + '}';
    }

    @Override
    public String typeofVechile() {
       return "The type  of vechile is  bicycle";
    }

    @Override
    public String CostofVechile() {
        return "The cost of Vechile is $1000.0";
    }
    
    
}

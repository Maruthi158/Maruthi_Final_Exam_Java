/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question10_Example3;

import java.util.Scanner;

/**
 *
 * @author S541905
 */
public class RecursionExample3 {

    /**
     * @param args the command line arguments
     */
    public static double looping(int n) {
    //if(n==0)
       // throw new ArithmeticException("hey n should not be zero");
       System.out.println("The valueof a is "+n);
        return looping(n-1) + 1.0/n;
    } 
    public static void main(String[] args) {
        // TODO code application logic here
          System.out.println("answer to question10 example for infiniterecursion: Priyanka Maruthi");
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter the value of a");
        int a=scan.nextInt();
        System.out.println(looping(a));
    }
    
}

//WashingMachine
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1;

/**
 *
 * @author Priyanka Maruthi
 */
public class WashingMachine extends ElectronicGoods  {
      private int id;
    private String Color;
    private String typeofWM;

    public WashingMachine(int id, String Color, String typeofWM) {
        this.id = id;
        this.Color = Color;
        this.typeofWM = typeofWM;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public String getTypeofWM() {
        return typeofWM;
    }

    public void setTypeofWM(String typeofWM) {
        this.typeofWM = typeofWM;
    }

    @Override
    public String toString() {
        return "WashingMachine{" + "id=" + id + ", Color=" + Color + ", typeofWM=" + typeofWM + '}';
    }

    @Override
    public String typeOfElectronicItem() {
        return "This is a Washing Machine";
    }

    @Override
    public double priceOfElectronicItem() {
        return 900.0;
    }
    
}

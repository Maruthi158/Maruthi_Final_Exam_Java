/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question9_Example1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author S541905
 */
public class ThrowsExample1 {
static void GenerateException()
    {
        try
        {
            System.out.println("Inside try block before throwing NullPointerException ");
            throw new NullPointerException("Hey I am throwing Null pointer Exception");
        }
        catch(NullPointerException e)
        {
            System.out.println("Inside catch block for NullPointerException");
            System.out.println("Caught inside GenerateException.");
            throw e; // rethrowing the exception
        }
    }
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException
     {
         System.out.println("The answer for Question9 as follows by Priyanka Maruthi");
         System.out.println("Throw and Throws example 1");
         System.out.println("********************************");
         try{
             System.out.println("Inside try block for FileNotFoundException ");   
         Scanner scan=new Scanner(new File("input.txt"));
         }
         catch(FileNotFoundException ex)
         { System.out.println("Inside catch block for FileNotFoundException ");   
             System.out.println("File not found");
         }
        
    try
        { System.out.println("********************************");
            System.out.println("Inside try block to call static method : GenerateException");   
            GenerateException();
        }
        catch(NullPointerException e)
        {
            System.out.println("Inside catch block inside main : GenerateException");   
           
        }
    }
}
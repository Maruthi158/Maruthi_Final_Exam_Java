/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Example_unchecked2;

/**
 *
 * @author S541905
 */
public class Unchecked2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         System.out.println("The answer for Question6 as follows by Priyanka Maruthi");
        System.out.println("Example  for unchecked exceptions");
    try  
        {  
        int data=50/0; //may throw exception   
        }  
            //handling the exception  
        catch(ArithmeticException e)  
        {  
            System.out.println("exception Caught" );  
        }  
        System.out.println("rest of the code");  
    }  
      
}  

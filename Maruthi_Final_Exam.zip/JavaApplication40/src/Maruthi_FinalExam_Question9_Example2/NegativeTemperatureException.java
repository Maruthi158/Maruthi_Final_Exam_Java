//NegativeTemperatureException.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question9_Example2;

/**
 *
 * @author S541905
 */
public class NegativeTemperatureException extends RuntimeException{

    public NegativeTemperatureException() {
    }

   public  NegativeTemperatureException(String msg) {
        super(msg);
    }
    
}

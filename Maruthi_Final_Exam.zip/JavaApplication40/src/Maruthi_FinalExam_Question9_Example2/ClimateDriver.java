//ClimateDriver.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question9_Example2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author S541905
 */
public class ClimateDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        System.out.println("The answer for Question9 as follows by Priyanka Maruthi");
        System.out.println("Question9 example2");
      Scanner scan = new Scanner(new File("weatherData.txt"));
        System.out.println("****************************");
          while(scan.hasNext()){
  
        String dir=scan.next();//reads only one word or token
        
          double temp=scan.nextDouble();

            boolean isSnow=scan.nextBoolean();
             Climate w2=new Climate(dir,temp,isSnow);
                  System.out.println(w2);//to console
                   System.out.println("****************************");
                  try{
                       System.out.println("****************************");
                      System.out.println("Inside try of main block");
                  System.out.println(w2.checkTemperature());
                  }
                  catch(NegativeTemperatureException ex){
                       System.out.println("****************************");
                      System.out.println("Inside catch inside main to execute to handle NegativeTemperatureException");
                      System.out.println("Please take care temperature below 0.0 degree celsius");
                       System.out.println("****************************");
          }
                  
          }
          scan.close();
        
                 
            
            
          
        
    }
    
}

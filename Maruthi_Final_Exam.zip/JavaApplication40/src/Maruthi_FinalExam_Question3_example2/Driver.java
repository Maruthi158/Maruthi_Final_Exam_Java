//Driver.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question3_example2;

/**
 *
 * @author Priyanka Maruthi
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   // TODO code application logic here
        System.out.println("The answer for Question3 as follows by Priyanka Maruthi");
        System.out.println("Casting Example2");
        System.out.println("*************************************");
        System.out.println("Base class:Parent student");
        Student stu1 = new Student("Priyanka", "Maruthi", "123-33-5432");
        Student stu3 = new Student("Jethin", "Maruthi", "12-33-5432");
        System.out.println(stu1);
        System.out.println(stu3);
        System.out.println("*************************************");
      System.out.println("child class:Fulltimestudent");
        FullTimeStudent stu2 = new FullTimeStudent(Boolean.FALSE,3,"Jethin", "Yadav", "123-33-5492");
        FullTimeStudent stu4 = new FullTimeStudent(Boolean.TRUE,3,"Priyanka", "Yadav", "123-03-5492");
        System.out.println(stu2); 
         System.out.println(stu4); 
          System.out.println("*************************************");
          System.out.println("Type casting objects");
          System.out.println("We are casting stu1 and stu3 to be an FullTimeStudent object. ");
           stu1 = stu2; 
        stu2 = (FullTimeStudent) stu1;
        System.out.println(stu2.toString());
           stu3 = stu4; 
        stu4 = (FullTimeStudent) stu3;
        System.out.println(stu4.toString());
    }
    
}


//ComparableCircle.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question5;

/**
 *
 * @author Priyanka Maruthi
 */
public class ComparableCircle extends Circle 
		implements Comparable<ComparableCircle> {

	
	/** Construct a ComparableCircle with specified properties */
	public ComparableCircle(double radius, String color, boolean filled) {
		super(radius, color, filled);
	}

	@Override // Implement the compareTo method defined in Comparable
	public int compareTo(ComparableCircle y) {
		if (getArea() > y.getArea())
			return 1;
		else if (getArea() < y.getArea())
			return -1;
		else
			return 0;
	}

	@Override // Implement the toString method defined in Circle
	public String toString() {
		return super.toString() + "\nArea: " + getArea();
	}
}

//AirConditioner
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1;

/**
 *
 * @author Priyanka Maruthi
 */
public class AirConditioner extends ElectronicGoods {
      private int id;
    private String Color;
    private String typeofAC;

    public AirConditioner(int id, String Color, String typeofAC) {
        this.id = id;
        this.Color = Color;
        this.typeofAC = typeofAC;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public String getTypeofAC() {
        return typeofAC;
    }

    public void setTypeofAC(String typeofAC) {
        this.typeofAC = typeofAC;
    }

    @Override
    public String toString() {
        return "AirConditioner{" + "id=" + id + ", Color=" + Color + ", typeofAC=" + typeofAC + '}';
    }

    @Override
    public String typeOfElectronicItem() {
        return "This is an Air Conditioner";
    }

    @Override
    public double priceOfElectronicItem() {
        return 400.0;
    }
    

    
}

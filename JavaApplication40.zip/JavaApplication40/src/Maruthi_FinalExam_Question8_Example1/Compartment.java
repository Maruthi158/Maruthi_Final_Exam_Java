//Compartment.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question8_Example1;

/**
 *
 * @author Priyanka Maruthi
 */
public class Compartment {
  private int trainNumber;
    private String compartmentName;
    private int numberOfSeats;

    public Compartment(int trainNumber, String compartmentName, int numberOfSeats) {
        this.trainNumber = trainNumber;
        this.compartmentName = compartmentName;
        this.numberOfSeats = numberOfSeats;
    }

    public int getTrainNumber() {
        return trainNumber;
    }

    public void setTrainNumber(int trainNumber) {
        this.trainNumber = trainNumber;
    }

    public String getCompartmentName() {
        return compartmentName;
    }

    public void setCompartmentName(String compartmentName) {
        this.compartmentName = compartmentName;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }  //it will throw the  user defined exceptions
   public boolean checkCompartment() 
  {
   if(trainNumber==0000){
      throw new WrongTrainNumber("Please recheck the correct train number");    }
   else{
       System.out.println("No exception");
      return true;  
   }
        
      
      
    }
    @Override
    public String toString() {
        return "Compartment{" + "trainNumber=" + trainNumber + ", compartmentName=" + compartmentName + ", numberOfSeats=" + numberOfSeats + '}';
    }
    
}
  


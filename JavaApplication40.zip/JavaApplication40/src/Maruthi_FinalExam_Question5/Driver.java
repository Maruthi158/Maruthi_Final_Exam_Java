//Driver.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question5;

/**
 *
 * @author S541905
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    // Create two instances of ComparableCircle objects
        System.out.println("The answer for Question5 as follows by Priyanka Maruthi");
		ComparableCircle comp1 = new ComparableCircle(12.5,"Green",Boolean.TRUE);
		ComparableCircle comp2 = new ComparableCircle(18.3,"Red",Boolean.FALSE);

		// Display comparableCircles
		System.out.println("\nComparableCircle1:");
		System.out.println(comp1);
		System.out.println("\nComparableCircle2:");
		System.out.println(comp2);

		// Find and display the larger of the two ComparableCircle objects
		if((comp1.compareTo(comp2) == 1))
                       System.out.println("ComparableCircle1 is the larger of the two Circles");
			else
                     System.out.println("ComparableCircle2 is the larger of the two Circles");
                    
	}}

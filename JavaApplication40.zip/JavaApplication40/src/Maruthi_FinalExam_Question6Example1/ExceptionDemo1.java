/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question6Example1;

/**
 *
 * @author S541905
 */
public class ExceptionDemo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("The answer for Question6 as follows by Priyanka Maruthi");
        System.out.println("Example 1 for exceptions");
         System.out.println("Demo for Runtime Exception: ");
         System.out.println("Unchecked exceptions");
         System.out.println("Demonstrating NullPointerException with try catch");
    try {
           
            String str1 = null; // null value
            System.out.println(str1.charAt(0));
        }
        catch (NullPointerException e) {
            System.out.println("NullPointerException..");
        }
      System.out.println("ArrayIndexOutOfBoundsException with try catch");
    try{
          int a[] = new int[5];
            a[6] = 9; // accessing 7th element in an array of
    }
    catch(ArrayIndexOutOfBoundsException ex){
        System.out.println("Array Index out of bound");
    }
    
     
    }
}
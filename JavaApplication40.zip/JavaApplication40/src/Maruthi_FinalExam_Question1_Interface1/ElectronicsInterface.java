//ElectronicsInterface.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1_Interface1;


/**
 *
 * @author Priyanka Maruthi
 */
public  interface ElectronicsInterface {
     public static final String powerSupply="YES";
     public abstract String typeOfElectronics();
     //default method
     default String isPowerSupply(){
         return "The power supply is required";
     }
    
}

//ElectronicInterfaceDriver.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1_Interface1;

/**
 *
 * @author Priyanka Maruthi
 */
public class ElectronicInterfaceDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("The answer for Question 1 as follows by Priyanka Maruthi");
        System.out.println("Interface Example 1");
        Microwave m1=new Microwave(10,"black",20);
        System.out.println("to string for Microwave class");
        System.out.println(m1);
        System.out.println("Invoking abstract method:typeOfElectronics using Microwave object");
        System.out.println(m1.typeOfElectronics());
        System.out.println("Invoking default method:isPowerSupply using Microwave object");
        System.out.println(m1.isPowerSupply());
        System.out.println("***********************************");
        Fridge w2=new Fridge(101,"green",200);
        System.out.println("to string for Fridge");
        System.out.println(w2);
        System.out.println("Invoking abstract method:typeOfElectronics using Fridge object");
        System.out.println(w2.typeOfElectronics());
        System.out.println("Invoking default method:isPowerSupply using Fridge object");
        System.out.println(w2.isPowerSupply());
        System.out.println("***********************************");
        System.out.println("Invoking Constant of abstract class using Fridge and Microwave objects");
        System.out.println("Microwave object constant access        "+m1.powerSupply);
        System.out.println("Fridge object constant access          "+w2.powerSupply);
        
    }
    
}

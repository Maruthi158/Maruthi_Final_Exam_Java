//Fridge.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1_Interface1;

/**
 *
 * @author Priyanka Maruthi
 */
public class Fridge implements ElectronicsInterface {
       private int modelNo;
    private String color;
    private int price;

    public Fridge(int modelNo, String color, int price) {
        this.modelNo = modelNo;
        this.color = color;
        this.price = price;
    }

    public int getModelNo() {
        return modelNo;
    }

    public void setModelNo(int modelNo) {
        this.modelNo = modelNo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Fridge{" + "modelNo=" + modelNo + ", color=" + color + ", price=" + price + '}';
    }

    @Override
    public String typeOfElectronics() {
       return "The type of Electornic item would be Fridge";
    }

    @Override
    public String isPowerSupply() {
       return "The power supply is required for  Fridge";
    }
    
    
}

//Guitar.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1_Interface2;

/**
 *
 * @author Priyanka Maruthi
 */
public class Guitar implements MusicalInstruments {
    private double price;
    private String size;
    private String typeofGuitar;

    public Guitar(double price, String size, String typeofGuitar) {
        this.price = price;
        this.size = size;
        this.typeofGuitar = typeofGuitar;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getTypeofGuitar() {
        return typeofGuitar;
    }

    public void setTypeofGuitar(String typeofGuitar) {
        this.typeofGuitar = typeofGuitar;
    }

    @Override
    public String toString() {
        return "Guitar{" + "price=" + price + ", size=" + size + ", typeofGuitar=" + typeofGuitar + '}';
    }

    @Override
    public String typeofMusicalInstrument() {
        return "The type of musical instrument is Guitar";
    }
    
    
    
}

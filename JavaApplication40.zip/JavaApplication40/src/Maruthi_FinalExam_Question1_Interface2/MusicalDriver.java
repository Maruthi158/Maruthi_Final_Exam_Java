//MusicalDriver.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1_Interface2;

/**
 *
 * @author Priyanka Maruthi
 */
public class MusicalDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("The answer for Question 1 as follows by Priyanka Maruthi");
        System.out.println("Interface Example 2");
        Guitar G1=new Guitar(100,"SMALL","Electronic");
        System.out.println("to string for Guitar class");
        System.out.println(G1);
        System.out.println("Invoking abstract method:typeofMusicalInstrument using Guitar object");
        System.out.println(G1.typeofMusicalInstrument());
        System.out.println("Invoking default method:isInstrumentRequiresBattery using Guitar object");
        System.out.println(G1.isInstrumentRequiresBattery());
        System.out.println("***********************************");
        Drums D2=new Drums(1001,"single");
        System.out.println("to string for Drums");
        System.out.println(D2);
        System.out.println("Invoking abstract method:typeofMusicalInstrument using Drums object");
        System.out.println(D2.typeofMusicalInstrument());
        System.out.println("Invoking default method:isInstrumentRequiresBattery using Drums object");
        System.out.println(D2.isInstrumentRequiresBattery());
        System.out.println("***********************************");
        System.out.println("Invoking Constant of abstract class using Drums and Guitar objects");
        System.out.println("Guitar object constant access        "+G1.isMusicPlayable);
        System.out.println("Drums object constant access          "+D2.isMusicPlayable);
        
    }
    
}

    
    


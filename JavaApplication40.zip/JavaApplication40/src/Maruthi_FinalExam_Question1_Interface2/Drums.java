//Drums.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question1_Interface2;

/**
 *
 * @author Priyanka Maruthi
 */
public class Drums implements MusicalInstruments{
     private double price;
    private String typeofDrums;

    public Drums(double price, String typeofDrums) {
        this.price = price;
        this.typeofDrums = typeofDrums;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getTypeofDrums() {
        return typeofDrums;
    }

    public void setTypeofDrums(String typeofDrums) {
        this.typeofDrums = typeofDrums;
    }

    @Override
    public String toString() {
        return "Drums{" + "price=" + price + ", typeofDrums=" + typeofDrums + '}';
    }

    @Override
    public String typeofMusicalInstrument() {
         return "The type of musical instrument is Drums";
    }

    @Override
    public String isInstrumentRequiresBattery() {
         return "The battery not required for the musical instrument:Drums";
    }
    
    
}

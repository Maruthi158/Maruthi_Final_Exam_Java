//ClassRoom.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question11_Example3;

import java.util.Objects;

/**
 *
 * @author S541905
 */
public class ClassRoom {
    private int capacity;
    private String className;

    public ClassRoom(int capacity, String className) {
        this.capacity = capacity;
        this.className = className;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }
//The hashCode method is an inbuilt method that returns the integer hashed value of the input value. This method is used for hash tables in java which are used to implement some of the data structures classes.It is expected to return the same value for objects that are equal according to the equals(object) method.
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 13 * hash + this.capacity;
        hash = 13 * hash + Objects.hashCode(this.className);
        return hash;
    }
//This method will compare the current object with the object that is passed as parameter and it will return true if both are equal otherwise it will return false

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ClassRoom other = (ClassRoom) obj;
        if (this.capacity != other.capacity) {
            return false;
        }
        if (!Objects.equals(this.className, other.className)) {
            return false;
        }
        return true;
    }
    

    @Override
    public String toString() {
        return "ClassRoom{" + "capacity=" + capacity + ", className=" + className + '}';
    }
    
    
}

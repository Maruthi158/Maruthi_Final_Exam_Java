//SquareDriver.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FnalExam_Question2;

/**
 *
 * @author S541905
 */
public class SquareDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    System.out.println("The answer for Question2 as follows by Priyanka Maruthi");
   GeometricObject[] squa = {new Square(19.5), new Square(19), 
			new Square(18.6), new Square(22), new Square(9)};

		// Display the area and invoke the howToColor 
		// method for each GeometricObject
		for (int i = 0; i < squa.length; i++) {
		 	System.out.println("\nSquare Number :" + (i + 1));
		 	System.out.println("Area: " + squa[i].getArea());
		 	((Square)squa[i]).howToColor();
		 } 
	}
}

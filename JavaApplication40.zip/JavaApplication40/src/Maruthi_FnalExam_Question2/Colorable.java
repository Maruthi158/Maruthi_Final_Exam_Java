//Colorable.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FnalExam_Question2;

/**
 *
 * @author S541905
 */
public interface Colorable {
      public abstract void howToColor();
    
}

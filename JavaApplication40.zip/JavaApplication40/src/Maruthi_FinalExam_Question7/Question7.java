/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question7;

import java.util.Scanner;

/**
 *
 * @author S541905
 */
public class Question7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        System.out.println("The answer for Question7 as follows by Priyanka Maruthi");
        
		Scanner scan = new Scanner(System.in);

		
		int[] array1 = getArray();

		
		System.out.print("Enter the index of the array: ");
		try {
		
			System.out.println("The corresponding element value is " + 
				array1[scan.nextInt()]);
		}
		catch (ArrayIndexOutOfBoundsException ex) {
			System.out.println("Out of Bounds.");
		}
	}

	/** Returns an array with 100 randomly chosen integers */
	public static int[] getArray() {
		int[] array1 = new int[100];
		for (int i = 0; i < array1.length; i++) {
			array1[i] = (int)(Math.random() * 100) + 1;
		}
		return array1;
	}
}

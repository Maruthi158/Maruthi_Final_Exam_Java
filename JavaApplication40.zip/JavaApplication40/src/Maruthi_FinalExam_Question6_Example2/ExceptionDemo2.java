/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question6_Example2;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author S541905
 */
public class ExceptionDemo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, FileNotFoundException
    {
   System.out.println("The answer for Question6 as follows by Priyanka Maruthi");
        System.out.println("Example 2 for exceptions");
        
         System.out.println("checked exceptions");
         
         System.out.println("Demonstrating classnotfoundException and FileNotFoundException");
       
            Class temp = Class.forName(
                "exceptionDemo2"); // calling the exceptionDemo2 class
            
            Scanner scan=new Scanner(new File("input.txt"));
       
       
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_Question9_finalExam_example3;

/**
 *
 * @author S541905
 */
public class ThrowsExample3 {
     static void Generate() throws IllegalAccessException
    {
        System.out.println("Inside Generate(). ");
        throw new IllegalAccessException("Inside Generate");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("The answer for Question9 as follows by Priyanka Maruthi");
        System.out.println("throws example 3");
     try
        {
            Generate();
        }
        catch(IllegalAccessException ex)
        {
            System.out.println("caught inside main.");
        }
    }
}

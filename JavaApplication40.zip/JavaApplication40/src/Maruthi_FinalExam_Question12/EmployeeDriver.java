//EmployeeDriver.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question12;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
/**
 *
 * @author S541905
 */
public class EmployeeDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    System.out.println("The answer for Question12 as follows by Priyanka Maruthi");
        ArrayList<Employee> employee = new ArrayList<>();

        employee.add(new Employee(3, "Priyanka", 9000));
        employee.add(new Employee(4, "Vani", 20000));
        employee.add(new Employee(5, "Upen", 60000));
        employee.add(new Employee(2, "jethin", 6000));
        employee.add(new Employee(1, "Babu", 9000));
        System.out.println("**************Enhanced for loop*******************");
        for (Employee e1 : employee) {
            System.out.println(e1.toString());
        }
System.out.println("**************Sorting using employee id*******************");
        Collections.sort(employee);
        System.out.println();
        for (Employee e1 : employee) {
            System.out.println(e1.toString());
        }

        Comparator<Employee> compareBySal = new Comparator<Employee>() {
            @Override
            public int compare(Employee e1, Employee e2) {
                if (e1.getEmpSalary() > e2.getEmpSalary()) {
                    return 1;
                }
                if (e1.getEmpSalary() < e2.getEmpSalary()) {
                    return -1;
                } else {
                    return 0;
                }
            }
        };
System.out.println("**************Sorting using employee salary*******************");
        Collections.sort(employee, compareBySal);
        System.out.println();
        for (Employee e1: employee) {
            System.out.println(e1.toString());
        }

        Comparator<Employee> compareByName = new Comparator<Employee>() {
            @Override
            public int compare(Employee e1, Employee e2) {
                return e1.getEmpName().compareTo(e2.getEmpName());
            }
        };
        
     System.out.println("**************Sorting using employee name*******************");
        Collections.sort(employee, compareByName);
        System.out.println();
        for (Employee e1 : employee) {
            System.out.println(e1.toString());
        }
    }
}
//Train.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_FinalExam_Question11_Example1;

import java.util.Objects;

/**
 *
 * @author S541905
 */
public class Train {
  private int trainNo;
  private String trainName;
/* constructor for train class*/
    public Train(int trainNo, String trainName) {
        this.trainNo = trainNo;
        this.trainName = trainName;
    }
/* getter for trainNo */
    public int getTrainNo() {
        return trainNo;
    }
/* setter for trainNo */
    public void setTrainNo(int trainNo) {
        this.trainNo = trainNo;
    }
/* getter for trainName */
    public String getTrainName() {
        return trainName;
    }
/* setter for trainName */
    public void setTrainName(String trainName) {
        this.trainName = trainName;
    }
//The hashCode method is an inbuilt method that returns the integer hashed value of the input value. This method is used for hash tables in java which are used to implement some of the data structures classes.It is expected to return the same value for objects that are equal according to the equals(object) method.
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + this.trainNo;
        hash = 47 * hash + Objects.hashCode(this.trainName);
        return hash;
    }
//This method will compare the current object with the object that is passed as parameter and it will return true if both are equal otherwise it will return false
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Train other = (Train) obj;
        if (this.trainNo != other.trainNo) {
            return false;
        }
        if (!Objects.equals(this.trainName, other.trainName)) {
            return false;
        }
        return true;
    }
    
    
/*toString method*/
    @Override
    public String toString() {
        return "Train{" + "trainNo=" + trainNo + ", trainName=" + trainName + '}';
    }
  
}

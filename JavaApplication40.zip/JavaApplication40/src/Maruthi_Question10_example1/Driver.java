//Driver.java
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maruthi_Question10_example1;

import static Maruthi_Question10_example1.RecursionExample.arr1;
import static Maruthi_Question10_example1.RecursionExample.recSearch;

/**
 *
 * @author S541905
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      int x = 154;
         System.out.println("The answer for Question10 as follows by Priyanka Maruthi");
         System.out.println("Recursion example1");
        //Method call to find x
        int index = recSearch(arr1, 0, arr1.length-1, x);
        if (index != -1)
           System.out.println("Element " + x + " is present at index " +
                                                    index);
        else
            System.out.println("Element " + x + " is not present");
        }
 } 	 	